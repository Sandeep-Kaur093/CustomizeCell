//
//  ProgessTableViewCell.swift
//  CustomizeCell
//
//  Created by Dhiman on 2023-04-03.
//

import UIKit

class ProgessTableViewCell: UITableViewCell {

    @IBOutlet weak var progressValue: UILabel!
    
    @IBOutlet weak var myprogress: UIProgressView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        progressValue.text = "\(Int(myprogress.progress*100))%"
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
